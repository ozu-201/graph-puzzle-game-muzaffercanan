#include <iostream>
#include <fstream>
#include <vector>
#include "Graph.h"
#include "Edge.h"
#include "../../General/AbstractGraph.h"
#include "EdgeList.h"
#include "Edge.h"
#include "../Queue.h"
#include "../Node.h"

using namespace list;
using namespace std;
int main()
{
    //opens the fle and checks whether it can open it or not
    ifstream inputFile;
    inputFile.open("C:\\Users\\TEMP.OZUN.000\\Downloads\\lab\\201-DataStructures-CPP-master\\src\\List\\Graph\\eng.txt");
    if (!inputFile.is_open())
    {
        std::cerr << "Error opening file." << std::endl;
        return 1;
    }
    // Read words from the file
    std::vector<std::string> words;
    std::string word;
    while (inputFile >> word)
    {
        words.push_back(word);
    }

    //three graph are created with their type for 3,4,5 words
    Graph wordGraph3(words.size());
    Graph wordGraph4(words.size());
    Graph wordGraph5(words.size());


    //for 3 words wordgraph3,for 4 words wordgraph4,for 4 words wordgraph4 are generated
    //and edges are added to them
    for (int length = 3; length <= 5; ++length)
    {
        for (const std::string &word : words)
        {
            if (word.length() == 3)
            {
                wordGraph3.addEdge(1000, 1500);
            }
            else if (word.length() == 4)
            {
                wordGraph4.addEdge(150, 150);
            }
            else{
                wordGraph5.addEdge(200, 400);

            }

        }

        //connects the disjoint sets and then it can make the bread first search  for three words which we search
        //the number which has put , reads the line number and equalize it the word we want to search.
        wordGraph3.connectedComponentsDisjointSet();
        std::cout << "Connected Components (Length = 3" << length << "): " << wordGraph3.connectedComponentBfs() << std::endl;
        std::cout << "Connected Components (Length = 3" << length << "): " << wordGraph3.dijkstra(50,60) << std::endl;


        wordGraph4.connectedComponentsDisjointSet();
        std::cout << "Connected Components (Length = 4" << length << "): " << wordGraph4.connectedComponentBfs() << std::endl;
        std::cout << "Connected Components (Length = 4" << length << "): " << wordGraph4.dijkstra(50,60) << std::endl;


        wordGraph5.connectedComponentsDisjointSet();
        std::cout << "Connected Components (Length = 5" << length << "): " << wordGraph5.connectedComponentBfs() << std::endl;
        std::cout << "Connected Components (Length = 5" << length << "): " << wordGraph5.dijkstra(50,60) << std::endl;





    }

    return 0;
}

/*
 *  Graph graph3(3);
    graph3.addWord("cat");
    graph3.addWord("cot");
    graph3.addWord("cog");
    graph3.addWord("dog");
    graph3.addEdge("cat", "cot");
    graph3.addEdge("cot", "cog");
    graph3.addEdge("cog", "dog");

    std::cout << "Test Case: Adding Edges with One-Letter Difference (3 letter words)\n";
    std::cout << "Shortest Path from 'cat' to 'dog' (BFS):\n";
    graph3.BFS("cat", "dog");
    std::cout << "Shortest Path from 'cat' to 'dog' (Dijkstra):\n";
    graph3.Dijkstra("cat", "dog");
    std::cout << "------------------------------------------\n";
 * */