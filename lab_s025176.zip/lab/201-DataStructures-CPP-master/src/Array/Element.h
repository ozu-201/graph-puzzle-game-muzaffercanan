//
// Created by Olcay Taner YILDIZ on 20.03.2023.
//

#ifndef DATASTRUCTURES_CPP_ELEMENT_H
#define DATASTRUCTURES_CPP_ELEMENT_H

namespace array {

    class Element {
    private:
        int data;
    public:
        Element();

        explicit Element(int data);

        int getData();
    };

}
#endif //DATASTRUCTURES_CPP_ELEMENT_H
