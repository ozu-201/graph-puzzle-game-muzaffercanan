//
// Created by Olcay Taner YILDIZ on 25.04.2023.
//

#include "DHeap.h"

DHeap::DHeap(int N, int d) : Heap(N){
    this->d = d;
}
